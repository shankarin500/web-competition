import React, { useState, useEffect } from 'react';
import './index.css';

function App() {
  const [transactions, setTransactions] = useState([]);
  const [formData, setFormData] = useState({
    type: 'Expense',
    category: '',
    amount: '',
    date: '',
    description: ''
  });
  const [totalAmount, setTotalAmount] = useState(0);

  useEffect(() => {
    fetch('http://localhost:5000/get_transactions')
      .then(response => response.json())
      .then(data => {
        setTransactions(data.transactions);
        calculateTotal(data.transactions); // Update total amount when transactions are fetched
      })
      .catch(error => console.error('Error fetching transactions:', error));
  }, []);

  const calculateTotal = (transactions) => {
    const total = transactions.reduce((acc, transaction) => {
      const amount = parseFloat(transaction[3]);
      return transaction[1] === 'Income' ? acc + amount : acc - amount;
    }, 0);
    setTotalAmount(total);
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    fetch('http://localhost:5000/add_transaction', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    })
    .then(() => {
      setFormData({
        type: 'Expense',
        category: '',
        amount: '',
        date: '',
        description: ''
      });
      return fetch('http://localhost:5000/get_transactions');
    })
    .then(response => response.json())
    .then(data => {
      setTransactions(data.transactions);
      calculateTotal(data.transactions); // Update total amount after adding a transaction
    })
    .catch(error => console.error('Error adding transaction:', error));
  };

  return (
    <div>
      <h1>Expense Tracker</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="category"
          placeholder="Category"
          value={formData.category}
          onChange={handleChange}
          required
        />
        <input
          type="number"
          name="amount"
          placeholder="Amount"
          value={formData.amount}
          onChange={handleChange}
          required
        />
        <input
          type="date"
          name="date"
          value={formData.date}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="description"
          placeholder="Description"
          value={formData.description}
          onChange={handleChange}
        />
        <select name="type" value={formData.type} onChange={handleChange}>
          <option value="Income">Income</option>
          <option value="Expense">Expense</option>
        </select>
        <button type="submit">Add Transaction</button>
      </form>
      <h2>Total Amount: ${totalAmount.toFixed(2)}</h2>
      <h2>Transactions</h2>
      <ul>
        {transactions.map((transaction, index) => (
          <li key={index}>
            {transaction[4]} - {transaction[1]} - {transaction[2]} - ${parseFloat(transaction[3]).toFixed(2)} - {transaction[5]}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
