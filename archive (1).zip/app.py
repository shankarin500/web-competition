from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3

app = Flask(__name__)
CORS(app)

def init_db():
    conn = sqlite3.connect('expenses.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT NOT NULL,
            category TEXT,
            amount REAL NOT NULL,
            date TEXT NOT NULL,
            description TEXT
        )
    ''')
    conn.commit()
    conn.close()

@app.route('/get_transactions', methods=['GET'])
def get_transactions():
    conn = sqlite3.connect('expenses.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM transactions')
    transactions = cursor.fetchall()
    conn.close()
    return jsonify({'transactions': transactions})

@app.route('/add_transaction', methods=['POST'])
def add_transaction():
    data = request.json
    conn = sqlite3.connect('expenses.db')
    cursor = conn.cursor()
    cursor.execute('INSERT INTO transactions (type, category, amount, date, description) VALUES (?, ?, ?, ?, ?)',
                   (data['type'], data['category'], data['amount'], data['date'], data['description']))
    conn.commit()
    conn.close()
    return jsonify({'message': 'Transaction added'}), 201

if __name__ == '__main__':
    init_db()  # Ensure the database is initialized when the app starts
    app.run(port=5000)
